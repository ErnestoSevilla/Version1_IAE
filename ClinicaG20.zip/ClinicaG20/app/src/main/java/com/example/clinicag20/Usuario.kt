package com.example.clinicag20

data class Usuario(
    var userID: String = "",
    var nombre: String = "",
    var email: String = "",
    var rol: String = "",
    var estado: Boolean = false,
    var pass: String = ""
) {
    // Función para convertir el objeto Usuario en un Map, útil para Firebase
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "userID" to userID,
            "nombre" to nombre,
            "email" to email,
            "rol" to rol,
            "estado" to estado,
            "pass" to pass
        )
    }
}

