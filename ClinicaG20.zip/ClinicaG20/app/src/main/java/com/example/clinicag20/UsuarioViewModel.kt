package com.example.clinicag20

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

class UsuarioViewModel : ViewModel() {
    private val db = Firebase.firestore
    private var _listaUsuarios = MutableLiveData<List<Usuario>>(emptyList())
    val listaUsuarios: LiveData<List<Usuario>> = _listaUsuarios

    init {
        obtenerUsuarios()
    }

    fun obtenerUsuarios() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val resultado = db.collection("usuarios").get().await()

                val usuarios = resultado.documents.mapNotNull { it.toObject(Usuario::class.java) }
                _listaUsuarios.postValue(usuarios)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun agregarUsuario(usuario: Usuario) {
        usuario.userID = UUID.randomUUID().toString()  // Genera un ID único
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.collection("usuarios").document(usuario.userID).set(usuario).await()
                _listaUsuarios.postValue(_listaUsuarios.value?.plus(usuario))

                // Coloca el nuevo usuario al inicio de la lista
                _listaUsuarios.postValue(listOf(usuario) + (_listaUsuarios.value ?: emptyList()))

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun actualizarUsuario(usuario: Usuario) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.collection("usuarios").document(usuario.userID).update(usuario.toMap()).await()
                _listaUsuarios.postValue(_listaUsuarios.value?.map { if (it.userID == usuario.userID) usuario else it })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun borrarUsuario(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.collection("usuarios").document(id).delete().await()
                _listaUsuarios.postValue(_listaUsuarios.value?.filter { it.userID != id })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

}