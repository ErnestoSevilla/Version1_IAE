package com.example.clinicag20

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.clinicag20.databinding.ActivityMainBinding
import android.widget.Toast
import android.text.TextWatcher
import android.text.Editable

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: UsuarioAdapter
    private lateinit var viewModel: UsuarioViewModel

    var usuarioEdit = Usuario()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Envía el enfoque al cuadro Nombre al iniciar la aplicación
        binding.etNombre.requestFocus()
        // Desactivar el botón de agregar inicialmente
        binding.btnAgregarUsuario.isEnabled = false

        // Inicializar ViewModel
        viewModel = ViewModelProvider(this)[UsuarioViewModel::class.java]
        viewModel.listaUsuarios.observe(this) { usuarios ->
            setupRecyclerView(usuarios)
        }

        // Configuración del Switch de Estado independiente del Observer
        binding.switchEstado.setOnCheckedChangeListener { _, isChecked ->
            binding.tvEstado.text = if (isChecked) "Activo" else "Inactivo"
        }

        // Agregar TextWatchers para validar en tiempo real
        setupTextWatchers()

        // Configurar el botón de agregar usuario con validación
        binding.btnAgregarUsuario.setOnClickListener {
            if (validarCampos()) {
                val usuario = Usuario(
                    userID = "",  // ID generado en ViewModel
                    nombre = binding.etNombre.text.toString(),
                    email = binding.etEmail.text.toString(),
                    rol = binding.etRol.text.toString(),
                    estado = binding.switchEstado.isChecked,
                    pass = binding.etPass.text.toString()
                )
                viewModel.agregarUsuario(usuario)
                limpiarCampos()
            } else {
                mostrarError("Por favor, completa todos los campos.")
            }
        }

        // Configurar el botón de actualizar usuario
        binding.btnActualizarUsuario.setOnClickListener {
            // Verificamos si usuarioEdit tiene datos válidos para actualizar
            if (usuarioEdit.userID.isNotEmpty()) {
                // Actualizamos el usuario seleccionado con los datos actuales en los campos
                usuarioEdit = usuarioEdit.copy(
                    nombre = binding.etNombre.text.toString(),
                    email = binding.etEmail.text.toString(),
                    rol = binding.etRol.text.toString(),
                    estado = binding.switchEstado.isChecked,
                    pass = binding.etPass.text.toString()
                )
                viewModel.actualizarUsuario(usuarioEdit)
                adapter.notifyDataSetChanged()

                // Limpiamos los campos, desactivamos el botón y restablecemos usuarioEdit
                limpiarCampos()
                usuarioEdit = Usuario()  // Restablece usuarioEdit a un estado vacío
            } else {
                mostrarError("Por favor, selecciona un usuario para actualizar.")
            }
        }
    } // <-- Cierre del método onCreate()

    // Configuración del RecyclerView
    private fun setupRecyclerView(listaUsuarios: List<Usuario>) {
        adapter = UsuarioAdapter(listaUsuarios, ::borrarUsuario, ::actualizarUsuario)
        binding.rvUsuarios.adapter = adapter
    }

    // Función para borrar un usuario
    private fun borrarUsuario(id: String) {
        viewModel.borrarUsuario(id)
    }

    // Función para actualizar los campos con los datos del usuario seleccionado
    private fun actualizarUsuario(usuario: Usuario) {
        usuarioEdit = usuario
        binding.etNombre.setText(usuarioEdit.nombre)
        binding.etEmail.setText(usuarioEdit.email)
        binding.etRol.setText(usuarioEdit.rol)
        binding.switchEstado.isChecked = usuarioEdit.estado
        binding.etPass.setText(usuarioEdit.pass)

        // Activar el botón de actualizar cuando se selecciona un usuario
        binding.btnActualizarUsuario.isEnabled = true
    }

    // Validar que todos los campos estén llenos
    private fun validarCampos(): Boolean {
        return binding.etNombre.text.isNotEmpty() &&
                binding.etEmail.text.isNotEmpty() &&
                binding.etRol.text.isNotEmpty() &&
                binding.etPass.text.isNotEmpty()
    }

    // Mostrar mensaje de error
    private fun mostrarError(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }

    // Limpiar los campos después de agregar o actualizar
    private fun limpiarCampos() {
        binding.etNombre.setText("")
        binding.etEmail.setText("")
        binding.etRol.setText("")
        binding.switchEstado.isChecked = false
        binding.etPass.setText("")

        // Desactivar el botón de agregar y actualizar después de limpiar los campos
        binding.btnAgregarUsuario.isEnabled = false
        binding.btnActualizarUsuario.isEnabled = false
    }

    // Configurar TextWatchers para activar el botón de agregar
    private fun setupTextWatchers() {
        val textWatcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                // Activar o desactivar el botón de agregar según los campos
                binding.btnAgregarUsuario.isEnabled = validarCampos()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }

        // Aplicar el TextWatcher a cada campo
        binding.etNombre.addTextChangedListener(textWatcher)
        binding.etEmail.addTextChangedListener(textWatcher)
        binding.etRol.addTextChangedListener(textWatcher)
        binding.etPass.addTextChangedListener(textWatcher)
    }
}
