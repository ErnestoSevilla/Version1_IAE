package com.example.clinicag20

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class UsuarioAdapter (
    val listaUsuarios: List<Usuario>,
    val onBorrarClick: (String) -> Unit,
    val onActualizarClick: (Usuario) -> Unit
    ) : RecyclerView.Adapter<UsuarioAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cvUsuario: CardView = itemView.findViewById(R.id.cvUsuario)
        val tvUserId: TextView = itemView.findViewById(R.id.tvUserId)
        val tvNombre: TextView = itemView.findViewById(R.id.tvNombre)
        val tvEmail: TextView = itemView.findViewById(R.id.tvEmail)
        val tvRol: TextView = itemView.findViewById(R.id.tvRol)
        val ibtnBorrar: ImageButton = itemView.findViewById(R.id.ibtnBorrar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_rv_tarea, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: UsuarioAdapter.ViewHolder, position: Int) {
        val usuario = listaUsuarios[position]

        // Asignar los valores de usuario a las vistas correspondientes
//      holder.tvUserId.text = usuario.userID el codigo es automatico
        holder.tvNombre.text = usuario.nombre
        holder.tvEmail.text = usuario.email
        holder.tvRol.text = usuario.rol

        // Manejar el clic del botón de eliminar
        holder.ibtnBorrar.setOnClickListener {
            onBorrarClick(usuario.userID)
        }

        // Manejar el clic en el CardView para actualizar
        holder.cvUsuario.setOnClickListener {
            onActualizarClick(usuario)
        }
    }

    override fun getItemCount(): Int {
        return listaUsuarios.size
    }
}